﻿using AdminThemeBC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;

namespace AdminThemeBC.Areas.CoffeeShop.Controllers
{
    [Area("CoffeeShop")]
    public class CustomerController : Controller
    {
        private IConfiguration _configuration;
        private Helper _helper;
        public CustomerController(IConfiguration configuration)
        {
            _configuration = configuration;
            _helper = new Helper(_configuration);
        }
        public IActionResult CustomerList()
        {
            return View(_helper.GetAllThings("SP_FindAllCustomers"));
        }
        public IActionResult AddEditCustomers()
        {
            ViewBag.Users = _helper.GetAllThings("SP_FindAllUsers");
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Save(CustomerModel customer)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("CustomersList");
            }
            else
            {
                return View("AddEditCustomers");
            }
        }
        public IActionResult CustomerDelete(int? CustomerID)
        {
            try
            {
                string connectionString = this._configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SP_DeleteCustomer";
                command.Parameters.Add("@CustomerID", SqlDbType.Int).Value = CustomerID;
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                TempData["ErrorMsg"] = e.Message;
            }
            return RedirectToAction("CustomerList");
        }
    }
}

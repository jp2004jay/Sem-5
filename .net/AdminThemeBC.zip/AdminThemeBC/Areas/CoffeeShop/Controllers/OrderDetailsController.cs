﻿using AdminThemeBC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;

namespace AdminThemeBC.Areas.CoffeeShop.Controllers
{
    [Area("CoffeeShop")]
    public class OrderDetailsController : Controller
    {
        private IConfiguration _configuration;
        private Helper _helper;
        public OrderDetailsController(IConfiguration configuration)
        {
            _configuration = configuration;
            _helper = new Helper(_configuration);
        }
        public IActionResult OrderDetailsList()
        { 
            return View(_helper.GetAllThings("SP_FindAllOrderDetails"));
        }
        public IActionResult AddEditOrderDetails()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Save(OrderDetailModel orderDetails)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("OrderDetailsList");
            }
            else
            {
                return View("AddEditOrderDetails");
            }
        }
        public IActionResult OrderDetailDelete(int? OrderDetailID)
        {
            try
            {
                string connectionString = this._configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SP_DeleteOrderDetail";
                command.Parameters.Add("@OrderDetailID", SqlDbType.Int).Value = OrderDetailID;
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                TempData["ErrorMsg"] = e.Message;
            }
            return RedirectToAction("OrderDetailsList");
        }
    }
}

﻿using AdminThemeBC.Models;
using System.Data;
using System.Data.SqlClient;

namespace AdminThemeBC.Areas.CoffeeShop.Controllers
{
    public class Helper
    {
        private string? _connectionString;
        SqlConnection connection;
        public Helper(IConfiguration configuration) 
        {
            _connectionString = configuration.GetConnectionString("ConnectionString");
            connection = new SqlConnection(_connectionString);
        }
        public DataTable GetAllThings(string storeProcedure)
        {
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = storeProcedure;
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            connection.Close();
            return table;
        }
        public List<UserModel> GetUsers() 
        {
            List<UserModel> userList = new List<UserModel>();

            foreach (DataRow data in GetAllThings("SP_FindAllUsers").Rows)
            {
                UserModel userModel = new UserModel();
                userModel.UserID = Convert.ToInt32(data["UserID"]);
                userModel.UserName = data["UserName"].ToString();
                Console.WriteLine(userModel.UserID);
                userList.Add(userModel);
            }
            return userList;
        }
        /*public List<CustomerModel> GetCustomers()
        {
            string name = "Customer";
            List<CustomerModel> customerList = new List<CustomerModel>();

            foreach (DataRow data in GetAllThings("SP_FindAllCustomers").Rows)
            {
                UserModel userModel = new UserModel();
                userModel.UserID = Convert.ToInt32(data[name+"ID"]);
                userModel.UserName = data["CustomerName"].ToString();
                Console.WriteLine(userModel.UserID);
               *//* userList.Add(userModel);*//*
            }
            *//*return userList;*//*
        }*/
    }
}

﻿using AdminThemeBC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis;
using NuGet.Protocol.Plugins;
using System.Configuration;

namespace AdminThemeBC.Areas.CoffeeShop.Controllers
{
    [Area("CoffeeShop")]
    public class ProductController : Controller
    {
        public IConfiguration _configuration;
        private Helper _helper;
        public ProductController(IConfiguration configuration)
        {
            _configuration = configuration;
            _helper = new Helper(_configuration);
        }
        public IActionResult ProductList()
        {
            return View(_helper.GetAllThings("SP_FindAllProducts"));
        }
        public IActionResult AddEditProduct()
        {
            ViewBag.UserList = _helper.GetUsers();
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Save(ProductModel product)
        {      
            if (ModelState.IsValid)
            {
                return RedirectToAction("ProductList");
            }
            else
            {
                ViewBag.UserList = _helper.GetUsers();
                return View("AddEditProduct", product);
            }
        }
        public IActionResult ProductDelete(int? ProductID)
        {
            try
            {
                string connectionString = this._configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SP_DeleteProduct";
                command.Parameters.Add("@ProductID", SqlDbType.Int).Value = ProductID;
                command.ExecuteNonQuery();
            }
            catch(Exception e)
            {
                TempData["ErrorMsg"] = e.Message;
            }
            return RedirectToAction("ProductList");
        }

    }
}

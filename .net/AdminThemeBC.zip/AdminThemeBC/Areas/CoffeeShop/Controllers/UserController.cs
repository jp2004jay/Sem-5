﻿using AdminThemeBC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;

namespace AdminThemeBC.Areas.CoffeeShop.Controllers
{
    [Area("CoffeeShop")]
    public class UserController : Controller
    {
        private IConfiguration _configuration;
        private Helper _helper;
        public UserController(IConfiguration configuration)
        {
            _configuration = configuration;
            _helper = new Helper(_configuration);
        }
        public IActionResult UserList()
        {
            return View(_helper.GetAllThings("SP_FindAllUsers"));
        }
        public IActionResult AddEditUser()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Save(UserModel user)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("UsersList");
            }
            else
            {
                return View("AddEditUser");
            }
        }
        public IActionResult UserDelete(int? UserID)
        {
            try
            {
                string connectionString = this._configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SP_DeleteUser";
                command.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                TempData["ErrorMsg"] = e.Message;
            }
            return RedirectToAction("UserList");
        }
    }
}

﻿using Microsoft.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace AdminThemeBC.Models
{
    public class ProductModel
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public double ProductPrice { get; set; }
        public string ProductCode { get; set; }
        public string Description { get; set; }
        public int UserID { get; set; }
    }
}

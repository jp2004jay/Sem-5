﻿using AdminThemeBC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;

namespace AdminThemeBC.Areas.CoffeeShop.Controllers
{
    [Area("CoffeeShop")]
    public class OrderController : Controller
    {
        private IConfiguration _configuration;
        private Helper _helper;
        public OrderController(IConfiguration configuration)
        {
            _configuration = configuration;
            _helper = new Helper(_configuration);
        }
        public IActionResult OrderList()
        {
            return View(_helper.GetAllThings("SP_FindAllOrders"));
        }
        public IActionResult AddEditOrders()
        {
            ViewBag.customers = _helper.GetCustomers();
            ViewBag.users = _helper.GetUsers();
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Save(OrderModel order)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("OrderList");
            }
            else
            {
                ViewBag.customers = _helper.GetCustomers();
                ViewBag.users = _helper.GetUsers();
                return View("AddEditOrders");
            }
        }
        public IActionResult OrderDelete(int? OrderID)
        {
            try
            {
                string connectionString = this._configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SP_DeleteOrder";
                command.Parameters.Add("@OrderID", SqlDbType.Int).Value = OrderID;
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                TempData["ErrorMsg"] = e.Message;
            }
            return RedirectToAction("OrderList");
        }
    }
}

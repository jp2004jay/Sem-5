﻿using AdminThemeBC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis;
using NuGet.Protocol.Plugins;
using System.Configuration;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
using System.Net.Mail;
using System.Net;

namespace AdminThemeBC.Areas.CoffeeShop.Controllers
{
    [Area("CoffeeShop")]
    public class ProductController : Controller
    {
        public IConfiguration _configuration;
        private Helper _helper;
        public ProductController(IConfiguration configuration)
        {
            _configuration = configuration;
            _helper = new Helper(_configuration);
        }
        public IActionResult ProductList()
        {
            return View(_helper.GetAllThings("SP_FindAllProducts"));
        }
        public IActionResult AddEditProduct()
        {
            ViewBag.UserList = _helper.GetUsers();
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Save(ProductModel product)
        {      
            if (ModelState.IsValid)
            {
                try
                {
                    // Set up the SMTP client configuration for Gmail
                    SmtpClient smtpClient = new SmtpClient("smtp.gmail.com")
                    {
                        Port = 587, // Gmail SMTP port for TLS
                        Credentials = new NetworkCredential("22010101478@darshan.ac.in", "Govind@101478#"),
                        EnableSsl = true, // Enable SSL for security
                    };

                    // Create a mail message
                    MailMessage mailMessage = new MailMessage
                    {
                        From = new MailAddress("22010101478@darshan.ac.in"),
                        Subject = "Hello, this is from my side",
                        Body = "Email send successfully",
                        IsBodyHtml = false, // Set to true if the body contains HTML
                    };


                    mailMessage.To.Add("ramanijay2004@gmail.com");
                    // Send the email
                    smtpClient.Send(mailMessage);

                    return Ok("Email sent successfully.");
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                    return BadRequest($"An error occurred while sending the email: {ex.Message}");
                }
                /*return RedirectToAction("ProductList");*/
            }
            else
            {
                ViewBag.UserList = _helper.GetUsers();
                return View("AddEditProduct", product);
            }
        }
        public IActionResult ProductDelete(int? ProductID)
        {
            try
            {
                string connectionString = this._configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SP_DeleteProduct";
                command.Parameters.Add("@ProductID", SqlDbType.Int).Value = ProductID;
                command.ExecuteNonQuery();
            }
            catch(Exception e)
            {
                TempData["ErrorMsg"] = e.Message;
            }
            return RedirectToAction("ProductList");
        }
        /*public IActionResult ExportFile(Int SubmittedFileType)
        {
            return View();
        }*/
    }
}

﻿using AdminThemeBC.Models;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using Microsoft.AspNetCore.Mvc;

namespace AdminThemeBC.Areas.CoffeeShop.Controllers
{
    public class Helper
    {
        private string? _connectionString;
        SqlConnection connection;
        public Helper(IConfiguration configuration) 
        {
            _connectionString = configuration.GetConnectionString("ConnectionString");
            connection = new SqlConnection(_connectionString);
        }
        public DataTable GetAllThings(string storeProcedure)
        {
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = storeProcedure;
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            connection.Close();
            return table;
        }
        public List<UserModel> GetUsers() 
        {
            List<UserModel> userList = new List<UserModel>();

            foreach (DataRow data in GetAllThings("SP_FindAllUsers").Rows)
            {
                UserModel userModel = new UserModel();
                userModel.UserID = Convert.ToInt32(data["UserID"]);
                userModel.UserName = data["UserName"].ToString();
                userList.Add(userModel);
            }
            return userList;
        }
        public List<CustomerModel> GetCustomers()
        {
            List<CustomerModel> customerList = new List<CustomerModel>();

            foreach (DataRow data in GetAllThings("SP_FindAllCustomers").Rows)
            {
                CustomerModel customerModel = new CustomerModel();
                customerModel.CustomerID = Convert.ToInt32(data["CustomerID"]);
                customerModel.CustomerName = data["CustomerName"].ToString();
                customerList.Add(customerModel);
            }
            return customerList;
        }
        public List<OrderModel> GetOrders()
        {
            List<OrderModel> orderList = new List<OrderModel>();

            foreach (DataRow data in GetAllThings("SP_FindAllOrders").Rows)
            {
                OrderModel orderModel = new OrderModel();
                orderModel.OrderID = Convert.ToInt32(data["OrderID"]);
                orderModel.OrderName = orderModel.OrderID.ToString();
                orderList.Add(orderModel);
            }
            return orderList;
        }
        public List<ProductModel> GetProducts()
        {
            List<ProductModel> productList = new List<ProductModel>();

            foreach (DataRow data in GetAllThings("SP_FindAllProducts").Rows)
            {
                ProductModel productModel = new ProductModel();
                productModel.ProductID = Convert.ToInt32(data["ProductID"]);
                productModel.ProductName = data["ProductName"].ToString();
                productList.Add(productModel);
            }
            return productList;
        }
    }
}

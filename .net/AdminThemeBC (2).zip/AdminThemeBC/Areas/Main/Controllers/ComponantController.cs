﻿using Microsoft.AspNetCore.Mvc;

namespace AdminThemeBC.Controllers
{
    [Area("Main")]
    public class ComponantController : Controller
    {
        public IActionResult Alert()
        {
            return View();
        }
        public IActionResult Accordian()
        {
            return View();
        }
        public IActionResult Badges()
        {
            return View();
        }
        public IActionResult Breadcrumbs()
        {
            return View();
        }
        public IActionResult Buttons()
        {
            return View();
        }
        public IActionResult Cards()
        {
            return View();
        }
        public IActionResult Carousel()
        {
            return View();
        }
        public IActionResult ListGroup()
        {
            return View();
        }
        public IActionResult Modal()
        {
            return View();
        }
        public IActionResult Tabs()
        {
            return View();
        }
        public IActionResult Pagination()
        {
            return View();
        }
        public IActionResult Progress()
        {
            return View();
        }
        public IActionResult Spinners()
        {
            return View();
        }
        public IActionResult Tooltips()
        {
            return View();
        }
    }
}



